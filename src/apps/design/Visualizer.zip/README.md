
  # UI Design with Flowbite-React

  This is a code bundle for UI Design with Flowbite-React. The original project is available at https://www.figma.com/design/kjyNQYZ2Ba3LdoFyFFvzTp/UI-Design-with-Flowbite-React.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  